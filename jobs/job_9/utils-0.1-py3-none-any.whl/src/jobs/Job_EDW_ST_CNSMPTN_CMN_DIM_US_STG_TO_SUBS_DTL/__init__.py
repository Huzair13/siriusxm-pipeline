"""
Package initialization for the Job_EDW_ST_CNSMPTN_CMN_DIM_US_STG_TO_SUBS_DTL job module.
"""