"""
Package initialization for the Jl_Frmwrk_EDW_EXEC_LOG joblet module.
"""