"""
Package initialization for the jobs module.
"""